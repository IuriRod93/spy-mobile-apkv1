"""
Device utilities for getting device information and unique identifiers
"""
import logging
import platform
import uuid
import hashlib
import os

logger = logging.getLogger(__name__)

def get_device_id():
    """
    Get a unique device identifier
    Returns: string identifier or None
    """
    try:
        # Try Android-specific methods first
        try:
            from jnius import autoclass
            # Android methods
            try:
                Build = autoclass('android.os.Build')
                device_id = Build.ID or Build.SERIAL or Build.FINGERPRINT
                if device_id and device_id != 'unknown':
                    # Hash the ID for privacy
                    hashed_id = hashlib.sha256(device_id.encode()).hexdigest()[:16]
                    logger.info(f"Android device ID obtained: {hashed_id}")
                    return hashed_id
            except:
                pass

            # Try Android Settings
            try:
                Settings = autoclass('android.provider.Settings$Secure')
                android_id = Settings.getString(None, Settings.ANDROID_ID)
                if android_id and android_id != '9774d56d682e549c':
                    hashed_id = hashlib.sha256(android_id.encode()).hexdigest()[:16]
                    logger.info(f"Android ID obtained: {hashed_id}")
                    return hashed_id
            except:
                pass

        except ImportError:
            logger.warning("jnius not available, trying plyer")

        # Try plyer uniqueid
        try:
            from plyer import uniqueid
            device_id = uniqueid.get_uid()
            if device_id:
                hashed_id = hashlib.sha256(str(device_id).encode()).hexdigest()[:16]
                logger.info(f"Plyer device ID obtained: {hashed_id}")
                return hashed_id
        except:
            pass

        # Fallback to system-based ID
        try:
            system = platform.system()
            if system == "Windows":
                # Windows machine GUID
                try:
                    import winreg
                    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                       r"SOFTWARE\Microsoft\Cryptography")
                    machine_guid = winreg.QueryValueEx(key, "MachineGuid")[0]
                    hashed_id = hashlib.sha256(machine_guid.encode()).hexdigest()[:16]
                    winreg.CloseKey(key)
                    logger.info(f"Windows machine GUID obtained: {hashed_id}")
                    return hashed_id
                except:
                    pass
            elif system == "Linux":
                # Linux machine ID
                try:
                    with open('/etc/machine-id', 'r') as f:
                        machine_id = f.read().strip()
                        hashed_id = hashlib.sha256(machine_id.encode()).hexdigest()[:16]
                        logger.info(f"Linux machine ID obtained: {hashed_id}")
                        return hashed_id
                except:
                    pass
            elif system == "Darwin":  # macOS
                # macOS hardware UUID
                try:
                    import subprocess
                    result = subprocess.run(['system_profiler', 'SPHardwareDataType'],
                                          capture_output=True, text=True, timeout=5)
                    for line in result.stdout.split('\n'):
                        if 'Hardware UUID:' in line:
                            hw_uuid = line.split(':')[1].strip()
                            hashed_id = hashlib.sha256(hw_uuid.encode()).hexdigest()[:16]
                            logger.info(f"macOS hardware UUID obtained: {hashed_id}")
                            return hashed_id
                except:
                    pass

        except Exception as e:
            logger.error(f"System-based ID error: {e}")

        # Final fallback: generate persistent UUID based on system info
        try:
            system_info = f"{platform.node()}-{platform.machine()}-{platform.processor()}-{os.getenv('USERNAME', '')}"
            persistent_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, system_info))
            hashed_id = hashlib.sha256(persistent_id.encode()).hexdigest()[:16]
            logger.info(f"Generated persistent device ID: {hashed_id}")
            return hashed_id
        except Exception as e:
            logger.error(f"Persistent ID generation error: {e}")

    except Exception as e:
        logger.error(f"Device ID error: {e}")

    # Ultimate fallback
    fallback_id = str(uuid.uuid4().hex)[:16]
    logger.warning(f"Using random fallback device ID: {fallback_id}")
    return fallback_id

def get_device_info():
    """
    Get comprehensive device information
    Returns: dict with device details
    """
    try:
        device_id = get_device_id()

        # Basic system info
        device_info = {
            'imei': device_id,
            'modelo': platform.machine() or 'Unknown',
            'sistema_operacional': f"{platform.system()} {platform.release()}",
            'nome': platform.node() or 'Unknown Device',
            'usuario': os.getenv('USER') or os.getenv('USERNAME') or 'Unknown',
            'departamento': 'Unknown'
        }

        # Try to get more detailed Android info
        try:
            from jnius import autoclass
            Build = autoclass('android.os.Build')
            device_info.update({
                'modelo': Build.MODEL or device_info['modelo'],
                'fabricante': Build.MANUFACTURER or 'Unknown',
                'versao_android': Build.VERSION.RELEASE or 'Unknown',
                'api_level': str(Build.VERSION.SDK_INT) if hasattr(Build.VERSION, 'SDK_INT') else 'Unknown'
            })
        except:
            pass

        logger.info(f"Device info collected: {device_info}")
        return device_info

    except Exception as e:
        logger.error(f"Device info collection error: {e}")
        return {
            'imei': get_device_id(),
            'modelo': 'Unknown',
            'sistema_operacional': 'Unknown',
            'nome': 'Unknown Device',
            'usuario': 'Unknown',
            'departamento': 'Unknown'
        }

def get_battery_info():
    """
    Get battery information
    Returns: dict with battery details
    """
    try:
        # Try Android battery info
        try:
            from jnius import autoclass
            Intent = autoclass('android.content.Intent')
            IntentFilter = autoclass('android.content.IntentFilter')
            PythonActivity = autoclass('org.kivy.android.PythonActivity')

            # Get battery status
            ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            battery_status = PythonActivity.mActivity.registerReceiver(None, ifilter)

            level = battery_status.getIntExtra('level', -1)
            scale = battery_status.getIntExtra('scale', -1)
            status = battery_status.getIntExtra('status', -1)

            battery_info = {
                'level': int((level / scale) * 100) if scale > 0 else 100,
                'charging': status == 2,  # BATTERY_STATUS_CHARGING
                'temperature': battery_status.getIntExtra('temperature', -1) / 10.0 if battery_status.getIntExtra('temperature', -1) != -1 else 25.0
            }

            logger.info(f"Android battery info: {battery_info}")
            return battery_info

        except ImportError:
            logger.warning("jnius not available for battery, trying plyer")

        # Try plyer battery
        try:
            from plyer import battery
            status = battery.get_state()
            if status:
                battery_info = {
                    'level': status.get('percentage', 100),
                    'charging': status.get('isCharging', False),
                    'temperature': status.get('temperature', 25.0)
                }
                logger.info(f"Plyer battery info: {battery_info}")
                return battery_info
        except:
            pass

    except Exception as e:
        logger.error(f"Battery info error: {e}")

    # Fallback
    battery_info = {
        'level': 100,
        'charging': False,
        'temperature': 25.0
    }
    return battery_info

def get_storage_info():
    """
    Get storage information
    Returns: dict with storage details
    """
    try:
        # Try Android storage info
        try:
            from jnius import autoclass
            StatFs = autoclass('android.os.StatFs')
            Environment = autoclass('android.os.Environment')

            # Get external storage
            external_dir = Environment.getExternalStorageDirectory()
            if external_dir:
                stat = StatFs(external_dir.getPath())
                block_size = stat.getBlockSizeLong()
                total_blocks = stat.getBlockCountLong()
                available_blocks = stat.getAvailableBlocksLong()

                storage_info = {
                    'total': block_size * total_blocks,
                    'used': block_size * (total_blocks - available_blocks),
                    'free': block_size * available_blocks,
                    'percent': ((total_blocks - available_blocks) / total_blocks) * 100 if total_blocks > 0 else 0
                }

                logger.info(f"Android storage info: {storage_info}")
                return storage_info

        except ImportError:
            logger.warning("jnius not available for storage, using psutil")

        # Try psutil for desktop
        try:
            import psutil
            storage = psutil.disk_usage('/')
            storage_info = {
                'total': storage.total,
                'used': storage.used,
                'free': storage.free,
                'percent': storage.percent
            }
            logger.info(f"psutil storage info: {storage_info}")
            return storage_info
        except:
            pass

    except Exception as e:
        logger.error(f"Storage info error: {e}")

    # Fallback
    storage_info = {
        'total': 1000000000,  # 1GB
        'used': 500000000,    # 500MB
        'free': 500000000,    # 500MB
        'percent': 50.0
    }
    return storage_info
